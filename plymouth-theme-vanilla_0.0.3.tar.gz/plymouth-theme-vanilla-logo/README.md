# Vanilla OS Plymouth
This package contains both logo and text variants.

---

Based on the Ubuntu MATE Plymouth theme.